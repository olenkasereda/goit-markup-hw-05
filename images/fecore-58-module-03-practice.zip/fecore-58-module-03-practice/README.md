# Frontend online 58

## Заняття 6:

- flex-контейнер та flex-елемент
- Властивість display:flex | inline-flex
- flex-вісі та властивість flex-direction
- Вирівнювання flex-елементів на вісі, властивості justify-content, align-items
- Багаторядкові flex-контейнери та властивість flex-wrap
- Властивість flex-елемента: width та flex-basis, flex-grow, flex-shrink
